Paper: [Deep Unsupervised Cardinality Estimation](http://www.vldb.org/pvldb/vol13/p279-yang.pdf)
Code Reference: [repo](https://github.com/naru-project/naru)
