Paper: [Learned Cardinalities: Estimating Correlated Joins with Deep Learning](https://arxiv.org/pdf/1809.00677.pdf)
Code Reference: [repo](https://github.com/andreaskipf/learnedcardinalities)
