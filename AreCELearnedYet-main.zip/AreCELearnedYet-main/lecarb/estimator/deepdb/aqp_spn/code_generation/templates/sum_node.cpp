if ({scope_check}) {{
{subtree_code}
    {result_calculation}
    {final_assert}
}}