Paper: [DeepDB: Learn from Data, not from Queries!](http://www.vldb.org/pvldb/vol13/p992-hilprecht.pdf)
Code Reference: [repo](https://github.com/DataManagementLab/deepdb-public)
